﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Api.Migrations
{
    public partial class PersonRemovedFields : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "People",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDateTime",
                value: new DateTime(2022, 11, 7, 15, 45, 7, 948, DateTimeKind.Local).AddTicks(5420));

            migrationBuilder.UpdateData(
                table: "People",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDateTime",
                value: new DateTime(2022, 11, 7, 15, 45, 7, 948, DateTimeKind.Local).AddTicks(5610));

            migrationBuilder.UpdateData(
                table: "People",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDateTime",
                value: new DateTime(2022, 11, 7, 15, 45, 7, 948, DateTimeKind.Local).AddTicks(5610));

            migrationBuilder.UpdateData(
                table: "People",
                keyColumn: "Id",
                keyValue: 4,
                column: "CreatedDateTime",
                value: new DateTime(2022, 11, 7, 15, 45, 7, 948, DateTimeKind.Local).AddTicks(5610));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "People",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDateTime",
                value: new DateTime(2022, 11, 7, 13, 9, 59, 86, DateTimeKind.Local).AddTicks(3970));

            migrationBuilder.UpdateData(
                table: "People",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDateTime",
                value: new DateTime(2022, 11, 7, 13, 9, 59, 86, DateTimeKind.Local).AddTicks(4000));

            migrationBuilder.UpdateData(
                table: "People",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDateTime",
                value: new DateTime(2022, 11, 7, 13, 9, 59, 86, DateTimeKind.Local).AddTicks(4000));

            migrationBuilder.UpdateData(
                table: "People",
                keyColumn: "Id",
                keyValue: 4,
                column: "CreatedDateTime",
                value: new DateTime(2022, 11, 7, 13, 9, 59, 86, DateTimeKind.Local).AddTicks(4000));
        }
    }
}
