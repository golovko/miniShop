﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Api.Migrations
{
    public partial class PersonUpdated : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Image",
                table: "People",
                type: "longtext",
                nullable: false)
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.AddColumn<bool>(
                name: "IsAdmin",
                table: "People",
                type: "tinyint(1)",
                nullable: false,
                defaultValue: false);

            migrationBuilder.InsertData(
                table: "People",
                columns: new[] { "Id", "Address", "CreatedDateTime", "Email", "Image", "IsAdmin", "Name", "Ocupation", "UpdatedDateTime", "Website" },
                values: new object[,]
                {
                    { 1, "Odesa", new DateTime(2022, 11, 7, 13, 9, 59, 86, DateTimeKind.Local).AddTicks(3970), "vasya@mail.new", "https://i.pravatar.cc/150", true, "Vasya", "PM", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "nosite.me" },
                    { 2, "Kyiv", new DateTime(2022, 11, 7, 13, 9, 59, 86, DateTimeKind.Local).AddTicks(4000), "kela@mail.new", "https://i.pravatar.cc/150", false, "Kolya", "Designer", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "site.me" },
                    { 3, "Lviv", new DateTime(2022, 11, 7, 13, 9, 59, 86, DateTimeKind.Local).AddTicks(4000), "dimon@mail.new", "https://i.pravatar.cc/150", false, "Dima", "Dev", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "yoursite.me" },
                    { 4, "Kharkiv", new DateTime(2022, 11, 7, 13, 9, 59, 86, DateTimeKind.Local).AddTicks(4000), "nik@mail.new", "https://i.pravatar.cc/150", false, "Nikita", "QA", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "mysite.me" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "People",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "People",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "People",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "People",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DropColumn(
                name: "Image",
                table: "People");

            migrationBuilder.DropColumn(
                name: "IsAdmin",
                table: "People");
        }
    }
}
